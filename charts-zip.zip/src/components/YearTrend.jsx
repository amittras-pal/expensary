import { Group } from "@mantine/core";
import dayjs from "dayjs";
import ReactECharts from "echarts-for-react";
import { useMemo, useRef } from "react";
import { colors, trendData } from "../data/stats";
import CategorySelection from "./CategorySelection";
import "./Chart.css";
import { abbreviateNumber, Arr12, formatCurrency } from "./utils";
import YearTrendTooltip from "./YearTrendTooltip";

const categories = [
  "Entertainment",
  "Finance",
  "Food & Drinks",
  "House & Utilities",
  "Lifestyle",
  "Travel/Transportation",
  "Uncategorized",
];

export default function YearTrend() {
  const chartRef = useRef(null);

  //   memoize
  const budgets = Arr12.map((k) => {
    return {
      value: trendData.budgets.find((m) => m.month === k + 1)?.amount ?? 0,
    };
  });
  //   memoize
  const spends = Arr12.map((k, i) => {
    const value = trendData.trend.find((m) => m.month === k + 1)?.total ?? 0;
    let itemColor = colors.indigo[6];
    if (value > budgets[i].value) itemColor = colors.red[6];
    else if (value < budgets[i].value) itemColor = colors.green[6];
    return {
      value,
      itemStyle: {
        color: itemColor,
        borderWidth: 3,
        borderColor: "#242424",
      },
    };
  });

  const categoriesSeries = useMemo(() => {
    const series = Object.fromEntries(categories.map((c) => [c, []]));
    Arr12.forEach((k) => {
      const data = trendData.trend.find((m) => m.month === k + 1);
      if (!data) {
        series.Entertainment.push(0);
        series.Finance.push(0);
        series["Food & Drinks"].push(0);
        series["House & Utilities"].push(0);
        series.Lifestyle.push(0);
        series["Travel/Transportation"].push(0);
        series.Uncategorized.push(0);
      } else {
        const Entertainment = data.categories.find(
          (c) => c.name === "Entertainment"
        );
        const Finance = data.categories.find((c) => c.name === "Finance");
        const FoodnDrinks = data.categories.find(
          (c) => c.name === "Food & Drinks"
        );
        const HousenUtilities = data.categories.find(
          (c) => c.name === "House & Utilities"
        );
        const Lifestyle = data.categories.find((c) => c.name === "Lifestyle");
        const Travel = data.categories.find(
          (c) => c.name === "Travel/Transportation"
        );
        const Uncategorized = data.categories.find(
          (c) => c.name === "Uncategorized"
        );

        // load color map from static / db to render line colors properly.
        series.Entertainment.push({
          value: Entertainment?.amount ?? 0,
        });
        series.Finance.push({
          value: Finance?.amount ?? 0,
        });
        series["Food & Drinks"].push({
          value: FoodnDrinks?.amount ?? 0,
        });
        series["House & Utilities"].push({
          value: HousenUtilities?.amount ?? 0,
        });
        series.Lifestyle.push({
          value: Lifestyle?.amount ?? 0,
        });
        series["Travel/Transportation"].push({
          value: Travel?.amount ?? 0,
        });
        series.Uncategorized.push({
          value: Uncategorized?.amount ?? 0,
        });
      }
    });
    return series;
  }, []);

  const chartConfig = useMemo(
    () => ({
      legend: {
        show: false,
        data: ["Budget", "Spent", ...categories],
        selected:
          ["Budget", "Spent", ...categories]?.reduce((acc, curr) => {
            return {
              ...acc,
              [curr]: ["Budget", "Spent"].includes(curr),
            };
          }, {}) ?? {},
      },
      tooltip: {
        trigger: "axis",
        valueFormatter: formatCurrency,
        position: (point, params, dom, rect, size) => {
          const [gridW] = size.viewSize;
          const [contentW] = size.contentSize;
          return [gridW - contentW - 10, 20];
        },
        formatter: YearTrendTooltip,
        borderWidth: 0,
        borderColor: "transparent",
        extraCssText: `background-color: ${colors.dark[8]};`,
        axisPointer: {
          label: {
            formatter: ({ value, seriesData }) => {
              const budget =
                seriesData.find((s) => s.seriesName === "Budget")?.data.value ??
                0;
              return (
                dayjs().month(parseInt(value)).format("MMMM") +
                (!budget ? " (No Data)" : "")
              );
            },
          },
          color: colors.red[2],
        },
      },
      xAxis: {
        type: "category",
        boundaryGap: false,
        data: Arr12,
        axisLabel: {
          formatter: (v) => dayjs().month(v).format("MMM"),
          color: colors.gray[5],
          rotate: 90,
          interval: 0, // set to 1 for mobile.
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: "dotted",
            width: 1,
            color: colors.dark[4],
            showMinLine: false,
            showMaxLine: false,
          },
        },
      },
      yAxis: {
        type: "value",
        splitLine: {
          show: true,
          lineStyle: {
            type: "dotted",
            width: 1,
            color: colors.dark[4],
            showMinLine: false,
            showMaxLine: false,
          },
        },
        axisLabel: {
          formatter: abbreviateNumber,
          color: colors.gray[5],
        },
      },
      series: [
        {
          name: "Budget",
          type: "line",
          smooth: "true",
          data: budgets,
          symbol: "circle",
          symbolSize: 10,
          lineStyle: {
            type: "dashed",
            width: 1,
            color: colors.gray[6],
          },
          itemStyle: {
            color: colors.gray[6],
            borderWidth: 3,
            borderColor: "#242424",
          },
        },
        {
          name: "Spent",
          type: "line",
          smooth: "true",
          data: spends,
          symbol: "circle",
          symbolSize: 14,
          lineStyle: {
            width: 1,
            color: colors.gray[3],
          },
        },
        ...Object.entries(categoriesSeries).map(([name, data]) => ({
          name,
          type: "line",
          smooth: true,
          data: data,
          symbol: "diamond",
          symbolSize: 8,
        })),
      ],
      grid: {
        left: 5,
        right: 5,
        top: 25,
        bottom: 5,
        containLabel: true,
      },
    }),
    [budgets, categoriesSeries, spends]
  );

  // const handleCategoryToggle = (e) => {
  //   const show = e.currentTarget.checked;
  //   const instance = chartRef.current.getEchartsInstance();
  //   const legend = instance.getOption().legend[0].data;
  //   const option = {
  //     legend: {
  //       selected: legend.reduce((acc, curr) => {
  //         return {
  //           ...acc,
  //           [curr]: show || ["Budget", "Spent"].includes(curr),
  //         };
  //       }, {}),
  //     },
  //   };
  //   instance.setOption(option);
  // };

  const events = useMemo(
    () => ({
      click: (e) => {
        const data = { budget: 0, spent: 0 };
        if (e.seriesName === "Budget") {
          data.budget = e.value;
          data.spent = spends.at(e.dataIndex).value;
          console.log({
            budget: e.value,
            spent: spends.at(e.dataIndex).value,
          });
        } else {
          data.budget = budgets.at(e.dataIndex).value;
          data.spent = e.value;
        }

        if (!data.budget) return;
        else console.log("should load the other chart.");
      },
    }),
    [budgets, spends]
  );

  return (
    <>
      <Group spacing="sm">
        <CategorySelection
          legends={["Budget", "Spent", ...categories]}
          getChart={() => chartRef.current?.getEchartsInstance()}
        />
      </Group>
      <ReactECharts
        ref={(e) => (chartRef.current = e)}
        style={{ width: "100%", height: "96%" }}
        option={chartConfig}
        onEvents={events}
      />
    </>
  );
}

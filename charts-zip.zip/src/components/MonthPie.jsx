import ReactECharts from "echarts-for-react";
import { colors, summary } from "../data/stats";

export default function MonthPie() {
  const sTransform = Object.entries(summary.summary)
    .map(([name, data]) => ({
      name: name,
      value: data.total,
      itemStyle: { color: colors[data.subCategories[0].color][6] },
      children: data.subCategories.map((subCat) => ({
        name: subCat.label,
        value: subCat.value,
        itemStyle: { color: colors[subCat.color][3] },
      })),
    }))
    .sort((n1, n2) =>
      n1.name?.toLowerCase().localeCompare(n2.name?.toLowerCase())
    );
  const config = {
    darkMode: true,
    series: {
      type: "sunburst",
      data: sTransform,
      sort: null,
      radius: [80, "92%"],
      itemStyle: {
        borderRadius: 6,
        borderWidth: 2,
        borderColor: "#242424",
      },
      label: {
        show: false,
      },
      emphasis: {
        label: {
          show: true,
        },
      },
    },
  };

  return (
    <ReactECharts
      option={config}
      style={{
        height: 500,
        width: 500,
      }}
    />
  );
}

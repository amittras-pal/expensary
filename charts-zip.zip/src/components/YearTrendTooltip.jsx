import { Box, Divider, Group, Text } from "@mantine/core";
import dayjs from "dayjs";
import { renderToString } from "react-dom/server";
import { formatCurrency } from "./utils";

export default function YearTrendTooltip(series, ticket, callback) {
  const month = dayjs().month(series[0].dataIndex).format("MMMM");
  const budget = series.find((s) => s.seriesName === "Budget")?.value ?? 0;  

  const seriesGroups = {
    default:
      series.filter((s) => ["Budget", "Spent"].includes(s.seriesName)) ?? [],
    categories:
      series.filter((s) => !["Budget", "Spent"].includes(s.seriesName)) ?? [],
  };

  //   Need to check working in React.v18
  return renderToString(
    <Box
      sx={() => ({
        minWidth: "220px",
      })}
    >
      <Text fz="sm" sx={(theme) => ({ color: theme.colors.gray[3] })}>
        {month}{" "}
        {!budget ? (
          <Text component="span" fs="italic" c="dimmed">
            (No Data)
          </Text>
        ) : (
          ""
        )}
      </Text>
      {budget > 0 && (
        <>
          <Divider my={4} variant="dashed" color="dark" />
          {seriesGroups.default.map((series) => (
            <RenderSeriesInfo key={series.seriesName} {...series} />
          ))}
          {seriesGroups.categories.length > 0 && (
            <>
              <Divider my={4} variant="dashed" color="dark" />
              {seriesGroups.categories.map((series) => (
                <RenderSeriesInfo key={series.seriesName} {...series} />
              ))}
            </>
          )}
        </>
      )}
    </Box>
  );
}

function RenderSeriesInfo(props) {

  return (
    <Group position="apart">
      {/* Add an Icon: use props.data.itemStyle */}
      <Text sx={(theme) => ({ color: theme.colors.gray[3] })}>
        {props.seriesName}:
      </Text>
      <Text sx={{color: props.color}}>
        {formatCurrency(props.data.value)}
      </Text>
    </Group>
  );
}

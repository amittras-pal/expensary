import { Box, createStyles, Group, Text } from "@mantine/core";
import dayjs from "dayjs";
import timezone from "dayjs/plugin/timezone";
import utc from "dayjs/plugin/utc";
import { useEffect, useState } from "react";
import MonthPie from "./MonthPie";

dayjs.extend(timezone);
dayjs.extend(utc);

const useChartTileClasses = createStyles((theme) => ({
  card: {
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.dark[6],
    boxShadow: theme.shadows.md,
    padding: theme.spacing.sm,
    height: "calc(100vh - 92px)",
  },
}));

export default function StatisticsLayout() {
  const { classes } = useChartTileClasses();
  const [date, setDate] = useState(dayjs());

  useEffect(() => {
    const timer = setInterval(() => {
      setDate(dayjs());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <Group
      spacing="sm"
      grow
      sx={(theme) => ({
        padding: theme.spacing.sm,
      })}
    >
      <Box className={classes.card}>
        <MonthPie />
        <Text>
          Asia/Kolkata: {date.tz("Asia/Kolkata").format("DD-MMM-YYYY hh:mm:ss a")}
        </Text>
        <Text>
          Africa/Abidjan:{" "}
          {date.tz("Africa/Abidjan").format("DD-MMM-YYYY hh:mm:ss a")}
        </Text>
        <Text>
          America/Merida:{" "}
          {date.tz("America/Merida").format("DD-MMM-YYYY hh:mm:ss a")}
        </Text>
        <Text>
          Asia/Aden: {date.tz("Asia/Aden").format("DD-MMM-YYYY hh:mm:ss a")}
        </Text>
        <Text>
          Europe/Gibraltar:{" "}
          {date.tz("Europe/Gibraltar").format("DD-MMM-YYYY hh:mm:ss a")}
        </Text>
      </Box>
      {/* <Box className={classes.card}>
        <YearTrend />
      </Box> */}
    </Group>
  );
}

export const Arr12 = [...Array(12).keys()];
const numAbbrFormat = new Intl.NumberFormat("en-IN", {
  notation: "compact",
  maximumFractionDigits: 2,
});
const currencyFormat = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
});
export function formatCurrency(amount = 0) {
  return currencyFormat.format(amount);
}
export function abbreviateNumber(value) {
  return numAbbrFormat.format(value);
}

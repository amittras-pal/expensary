import { Button, Checkbox, Divider, Popover, Text } from "@mantine/core";
import { useEffect, useState } from "react";

export default function CategorySelection(props) {
  const [selection, setSelection] = useState({});

  useEffect(() => {
    const instance = props.getChart();
    setSelection(instance.getOption().legend[0].selected);
  }, []);

  const handleCategoryToggle = (e) => {
    const instance = props.getChart();
    const update = {
      ...instance.getOption().legend[0].selected,
      [e.currentTarget.name]: e.currentTarget.checked,
    };
    setSelection(update);
    instance.setOption({ legend: { selected: update } });
  };

  return (
    <Popover width={200} position="bottom" shadow="md" trapFocus>
      <Popover.Target>
        <Button
          variant="default"
          sx={{
            fontWeight: "normal",
          }}
        >
          Chart Lines ({Object.values(selection).filter((c) => c).length}{" "}
          selected)
        </Button>
      </Popover.Target>
      <Popover.Dropdown>
        {props.legends.slice(0, 2).map((c) => (
          <Checkbox mb="xs" label={c} name={c} key={c} readOnly checked />
        ))}
        <Divider variant="dashed" color="gray" my="sm" />
        <Text c="dimmed" mb="sm" fz="sm">
          Individual Categories
        </Text>
        {props.legends.slice(2).map((c) => (
          <Checkbox
            key={c}
            label={c}
            name={c}
            color="green" // make the colors dynamic somehow.
            mb="xs"
            checked={selection[c] === true}
            onChange={handleCategoryToggle}
          />
        ))}
      </Popover.Dropdown>
    </Popover>
  );
}
